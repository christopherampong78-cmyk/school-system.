import { useEffect, useMemo, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useData } from '../data';
import { listDocs, putDoc, slug } from '../lib/db';

export default function MarkEntry() {
  const { students, subjects } = useData();
  const [exams, setExams] = useState([]);
  const [examId, setExamId] = useState('');
  const [subject, setSubject] = useState('');
  const [scores, setScores] = useState({});
  const [msg, setMsg] = useState('');

  useEffect(() => { listDocs('exams').then(e => { setExams(e); if (e[0]) setExamId(e[0].id); }); }, []);
  useEffect(() => { if (!subject && subjects.length) setSubject(subjects[0].name); }, [subjects, subject]);

  const exam = exams.find(e => e.id === examId);
  const max = Number(exam?.maxScore) || 100;
  const list = useMemo(() => (exam ? students.filter(s => s.className === exam.className && s.status !== 'inactive') : []), [exam, students]);

  useEffect(() => {
    setMsg('');
    if (!exam || !subject) return;
    getDoc(doc(db, 'marks', `${exam.id}_${slug(subject)}`))
      .then(s => setScores(s.exists() ? Object.fromEntries(Object.entries(s.data().scores || {}).map(([k, v]) => [k, String(v)])) : {}))
      .catch(() => setScores({}));
  }, [exam, subject]);

  async function save() {
    const out = {};
    for (const s of list) {
      const raw = scores[s.studentId];
      if (raw === undefined || raw === '') continue;
      const n = Number(raw);
      if (Number.isNaN(n) || n < 0 || n > max) { setMsg(`${s.name}: enter a mark from 0 to ${max}.`); return; }
      out[s.studentId] = n;
    }
    await putDoc('marks', `${exam.id}_${slug(subject)}`, { examId: exam.id, subject, scores: out });
    setMsg(`Saved ${Object.keys(out).length} marks for ${subject}.`);
  }

  return (
    <>
      <div className="page-head"><div><h2>Mark Entry</h2><p className="muted">Enter each student's mark for one subject at a time.</p></div></div>
      <div className="card">
        <div className="filters">
          <select value={examId} onChange={e => setExamId(e.target.value)}>
            {exams.map(e => <option key={e.id} value={e.id}>{e.name} · {e.className}</option>)}
          </select>
          <select value={subject} onChange={e => setSubject(e.target.value)}>
            {subjects.map(s => <option key={s.id}>{s.name}</option>)}
          </select>
        </div>
        {!exams.length && <p className="muted empty">No exams yet. Add one on the Examinations page first.</p>}
        {exam && <p className="hint">Marks are out of {max}. Leave a box empty if the student was absent.</p>}
        {list.map(s => (
          <div key={s.studentId} className="att-row">
            <span>{s.name}<small className="muted"> {s.studentId}</small></span>
            <input className="score" type="number" inputMode="decimal" min="0" max={max} value={scores[s.studentId] ?? ''}
              onChange={e => setScores(m => ({ ...m, [s.studentId]: e.target.value }))} />
          </div>
        ))}
        {msg && <p className="hint">{msg}</p>}
        {exam && list.length > 0 && <button className="btn primary block" onClick={save}>Save marks</button>}
      </div>
    </>
  );
}
