import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import {
  LayoutDashboard, GraduationCap, Users, Briefcase, Contact, Layers, BookOpen,
  CalendarCheck, Clock, Award, PenLine, Wallet, Moon, Sun, LogOut, Menu,
} from 'lucide-react';
import { useAuth } from '../auth';
import { useTheme } from '../theme';
import { school } from '../config/school';

const groups = [
  { title: 'Overview', items: [{ to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true }] },
  { title: 'Admissions & people', items: [
    { to: '/students', label: 'Students', icon: GraduationCap },
    { label: 'Parents / Guardians', icon: Users, soon: true },
    { label: 'Staff & Teachers', icon: Briefcase, soon: true },
    { to: '/id-cards', label: 'ID Cards & QR', icon: Contact },
  ] },
  { title: 'Academics', items: [
    { label: 'Classes & Subjects', icon: Layers, soon: true },
    { label: 'Attendance', icon: CalendarCheck, soon: true },
    { label: 'Timetables', icon: Clock, soon: true },
  ] },
  { title: 'Exams & finance', items: [
    { label: 'Examinations', icon: Award, soon: true },
    { label: 'Mark Entry', icon: PenLine, soon: true },
    { label: 'Fees & Payments', icon: Wallet, soon: true },
  ] },
];

export default function Layout() {
  const { profile, logout } = useAuth();
  const [theme, toggle] = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <div className={`shell ${open ? 'nav-open' : ''}`}>
      <aside className="sidebar no-print">
        <div className="brand">
          <img src={school.logo} alt="" />
          <div><b>{school.name}</b><span>{school.tagline}</span></div>
        </div>
        <nav onClick={() => setOpen(false)}>
          {groups.map(g => (
            <div key={g.title} className="nav-group">
              <p>{g.title}</p>
              {g.items.map(i => i.soon ? (
                <span key={i.label} className="nav-item disabled"><i.icon size={18} />{i.label}<em>Soon</em></span>
              ) : (
                <NavLink key={i.label} to={i.to} end={i.end} className="nav-item"><i.icon size={18} />{i.label}</NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="side-user">
          <div className="avatar">{(profile?.name || '?')[0]}</div>
          <div><b>{profile?.name}</b><span>{profile?.role}</span></div>
          <button className="icon-btn" onClick={logout} aria-label="Sign out"><LogOut size={18} /></button>
        </div>
      </aside>
      {open && <div className="scrim no-print" onClick={() => setOpen(false)} />}
      <div className="main">
        <header className="topbar no-print">
          <button className="icon-btn menu" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          <span className="pill">{school.academicYear} · {school.term}</span>
          {__DEMO__ && <span className="pill demo">Demo mode</span>}
          <button className="icon-btn" onClick={toggle} aria-label="Toggle dark mode">
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </header>
        <main className="content"><Outlet /></main>
      </div>
    </div>
  );
}
