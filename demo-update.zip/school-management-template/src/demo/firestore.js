import { store, save } from './store';

const clone = (x) => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
const snap = (path) => {
  const data = store.docs[path];
  return { id: path.split('/').pop(), exists: () => data !== undefined, data: () => clone(data) };
};

export const getFirestore = () => ({});
export const serverTimestamp = () => Date.now();
export const doc = (_db, ...parts) => ({ path: parts.join('/') });
export const collection = (_db, name) => ({ col: name });

export const getDoc = async (ref) => snap(ref.path);
export const getDocs = async (colRef) => ({
  docs: Object.keys(store.docs)
    .filter(p => p.startsWith(colRef.col + '/') && p.split('/').length === 2)
    .map(snap),
});
export const setDoc = async (ref, data) => { store.docs[ref.path] = clone(data); save(); };
export const updateDoc = async (ref, patch) => { store.docs[ref.path] = { ...store.docs[ref.path], ...patch }; save(); };

export const writeBatch = () => {
  const ops = [];
  return {
    set: (ref, data) => ops.push([ref.path, clone(data)]),
    commit: async () => { ops.forEach(([p, d]) => { store.docs[p] = d; }); save(); },
  };
};

export const runTransaction = async (_db, fn) => {
  const tx = {
    get: async (ref) => snap(ref.path),
    set: (ref, data) => { store.docs[ref.path] = clone(data); },
  };
  const out = await fn(tx);
  save();
  return out;
};
