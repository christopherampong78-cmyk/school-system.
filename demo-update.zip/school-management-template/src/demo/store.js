// In-memory "fake Firebase" used only in demo mode. Data is kept in this browser (localStorage).
import { school } from '../config/school';

const KEY = 'demo-db-v1';
const FIRST = ['Ama', 'Kofi', 'Yaa', 'Kwame', 'Abena', 'Yaw', 'Akosua', 'Kwesi', 'Efua', 'Fiifi', 'Adjoa', 'Kojo', 'Esi', 'Nana', 'Mavis', 'Samuel', 'Gifty', 'Isaac', 'Comfort', 'Daniel', 'Grace', 'Emmanuel', 'Patience', 'Joseph'];
const LAST = ['Mensah', 'Boateng', 'Asante', 'Owusu', 'Appiah', 'Osei', 'Adjei', 'Agyeman', 'Darko', 'Ampofo', 'Tetteh', 'Quaye'];

function seed() {
  const docs = {};
  const creds = {};
  creds['admin@demo.school'] = { uid: 'u-admin', password: 'admin123' };
  docs['users/u-admin'] = { role: 'admin', name: 'Demo Administrator' };
  creds['teacher@demo.school'] = { uid: 'u-teacher', password: 'teacher123' };
  docs['users/u-teacher'] = { role: 'teacher', name: 'Demo Teacher' };
  const classes = school.classes.slice(5);
  FIRST.forEach((f, i) => {
    const n = i + 1;
    const id = school.idPrefix + String(n).padStart(4, '0');
    const token = `${id}-DEMO${String(n).padStart(4, '0')}`;
    docs[`students/${id}`] = {
      name: `${f} ${LAST[i % LAST.length]}`, className: classes[i % classes.length],
      gender: i % 2 ? 'Male' : 'Female', guardianName: `Mr/Mrs ${LAST[(i + 3) % LAST.length]}`,
      guardianPhone: `024000${String(1000 + n)}`, photo: '', studentId: id, status: i === 7 ? 'inactive' : 'active',
    };
    docs[`tokens/${id}`] = { token };
    docs[`users/u-${id}`] = { role: 'student', studentId: id, name: docs[`students/${id}`].name };
    creds[`${id.toLowerCase()}@${school.authDomain}`] = { uid: `u-${id}`, password: token };
  });
  docs['meta/studentCounter'] = { next: FIRST.length + 1 };
  return { docs, creds };
}

let db;
try { db = JSON.parse(localStorage.getItem(KEY)); } catch { db = null; }
if (!db) db = seed();

export const store = db;
export const save = () => { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch { /* storage full */ } };
export const resetDemo = () => { localStorage.removeItem(KEY); location.reload(); };
