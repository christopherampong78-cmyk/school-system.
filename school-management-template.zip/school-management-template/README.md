# School Management Template (React + Firebase + Netlify)

Version 1 covers: staff/admin sign-in, student sign-in by ID + password, **Student Token** or **QR scan**,
student records (single or bulk add), printable **ID cards with QR**, a student portal, and a dashboard.
The sidebar already lists the next modules (marked "Soon").

## Set up a new client
1. Edit `src/config/school.js` (name, colour, ID prefix, classes, address, phone) and replace `public/logo.svg`.
   Give each client a **unique** `authDomain` (e.g. `students.clientname.local`).
2. Create a Firebase project. Enable **Authentication → Email/Password** and **Firestore**.
3. Paste `firestore.rules` into Firestore → Rules and publish.
4. Copy `.env.example` to `.env` and fill in the web app keys from Firebase project settings.
5. Create the first admin: in Authentication add a user (email + password), then in Firestore create
   `users/<that user's UID>` with fields `role: "admin"` and `name: "Your Name"`.
   (Use `role: "teacher"` for read-only staff.)
6. `npm install`, then `npm run dev`. Deploy: connect the repo to Netlify, add the same `VITE_` variables, deploy.

## How student login works
Adding a student creates: a record in `students`, a private token in `tokens` (admin-only), and a Firebase login
with email `<studentId>@<authDomain>` and the token as its password. The token (e.g. `RWA0001-K7P3QX2M`) is printed
on the ID card and encoded in the QR code. The Student Token tab and the QR scanner both sign in with it.

## Known limits (next steps)
- Re-issuing a lost token needs a Cloud Function (the Admin SDK) to change a student's password. Not included yet.
- Photos are resized to ~240px and stored inside the student record. Move to Firebase Storage for large schools.
- Anyone holding the card can sign in as that student, so the portal should only expose low-risk data until you add PINs.
- Not run end-to-end here (no network in the build sandbox). Run `npm install && npm run build` first and send me any error.
