import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';
import IdCards from './pages/IdCards';
import StudentPortal from './pages/StudentPortal';

function Guard({ roles, children }) {
  const { user, profile, loading } = useAuth();
  if (loading) return <div className="center-screen">Loading…</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (!profile) return <div className="center-screen">This account has no role yet. Ask the administrator to set it up.</div>;
  if (!roles.includes(profile.role)) return <Navigate to={profile.role === 'student' ? '/me' : '/'} replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/me" element={<Guard roles={['student']}><StudentPortal /></Guard>} />
      <Route element={<Guard roles={['admin', 'teacher']}><Layout /></Guard>}>
        <Route index element={<Dashboard />} />
        <Route path="students" element={<Students />} />
        <Route path="id-cards" element={<IdCards />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
