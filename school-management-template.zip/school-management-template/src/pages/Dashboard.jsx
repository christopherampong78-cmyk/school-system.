import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { GraduationCap, Layers, UserRound, Users } from 'lucide-react';
import { db } from '../firebase';
import { school } from '../config/school';

export default function Dashboard() {
  const [list, setList] = useState(null);
  useEffect(() => { getDocs(collection(db, 'students')).then(s => setList(s.docs.map(d => d.data()))); }, []);

  if (!list) return <p className="muted">Loading dashboard…</p>;

  const active = list.filter(s => s.status !== 'inactive');
  const boys = active.filter(s => s.gender === 'Male').length;
  const girls = active.filter(s => s.gender === 'Female').length;
  const byClass = school.classes.map(c => [c, active.filter(s => s.className === c).length]).filter(([, n]) => n > 0);
  const max = Math.max(1, ...byClass.map(([, n]) => n));
  const pct = boys + girls ? Math.round((boys / (boys + girls)) * 100) : 50;

  const stats = [
    ['Total students', list.length, GraduationCap, `Active: ${active.length}`],
    ['Classes in use', byClass.length, Layers, `of ${school.classes.length} classes`],
    ['Boys', boys, UserRound, 'Active students'],
    ['Girls', girls, Users, 'Active students'],
  ];

  return (
    <>
      <h2>Administrator Dashboard</h2>
      <p className="muted">Overview of enrollment and student ID cards.</p>
      <div className="stats">
        {stats.map(([label, value, Icon, sub]) => (
          <div key={label} className="card stat">
            <div><span>{label}</span><strong>{value}</strong></div>
            <div className="stat-icon"><Icon size={20} /></div>
            <small>{sub}</small>
          </div>
        ))}
      </div>
      <div className="two-col">
        <div className="card">
          <h3>Student demographics</h3>
          <div className="donut" style={{ background: `conic-gradient(var(--primary) 0 ${pct}%, #ec4899 ${pct}% 100%)` }}><span /></div>
          <p className="legend"><i style={{ background: 'var(--primary)' }} />Boys {boys} <i style={{ background: '#ec4899' }} />Girls {girls}</p>
        </div>
        <div className="card">
          <h3>Students per class</h3>
          {byClass.length === 0 && <p className="muted">No students yet. Add your first students on the Students page.</p>}
          {byClass.map(([c, n]) => (
            <div key={c} className="bar-row"><span>{c}</span><div><i style={{ width: `${(n / max) * 100}%` }} /></div><b>{n}</b></div>
          ))}
        </div>
      </div>
    </>
  );
}
