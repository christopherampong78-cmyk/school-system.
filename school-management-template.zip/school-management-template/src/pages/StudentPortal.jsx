import { useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { LogOut, Moon, Sun, Printer } from 'lucide-react';
import { db } from '../firebase';
import { useAuth } from '../auth';
import { useTheme } from '../theme';
import { school } from '../config/school';
import { CardBack, CardFront } from '../components/IdCard';

export default function StudentPortal() {
  const { profile, logout } = useAuth();
  const [theme, toggle] = useTheme();
  const [s, setS] = useState(null);
  const [token, setToken] = useState('');

  useEffect(() => {
    getDoc(doc(db, 'students', profile.studentId)).then(x => setS(x.data()));
    getDoc(doc(db, 'tokens', profile.studentId)).then(x => setToken(x.data()?.token || ''));
  }, [profile]);

  return (
    <div className="portal">
      <header className="topbar no-print">
        <b>{school.name}</b>
        <span style={{ flex: 1 }} />
        <button className="icon-btn" onClick={toggle} aria-label="Toggle dark mode">{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button>
        <button className="icon-btn" onClick={logout} aria-label="Sign out"><LogOut size={18} /></button>
      </header>
      <main className="content narrow">
        {!s ? <p className="muted">Loading your details…</p> : (
          <>
            <h2>Hello, {s.name.split(' ')[0]}</h2>
            <p className="muted">{s.className} · {school.academicYear} · {school.term}</p>
            <div className="card-pair print-area"><CardFront s={s} /><CardBack s={s} token={token} /></div>
            <button className="btn no-print" onClick={() => window.print()}><Printer size={16} /> Print my ID card</button>
            <p className="hint no-print">Keep your token private. Anyone with it can sign in as you.</p>
          </>
        )}
      </main>
    </div>
  );
}
